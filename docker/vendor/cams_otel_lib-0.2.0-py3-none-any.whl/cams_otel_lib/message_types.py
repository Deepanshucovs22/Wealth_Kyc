"""Message categories, subtypes, and log levels for structured OTEL event logging.

These match the mandatory log schema's ``message_category``/``message_subtype``/
``log_level`` enums field-for-field. New categories/subtypes can be added here
without breaking existing callers — treat this as an open, growing set.
"""

import logging
from enum import Enum

# Python's logging module has no native TRACE level; register one below DEBUG.
TRACE_LEVEL = 5
logging.addLevelName(TRACE_LEVEL, "TRACE")


class MessageCategory(str, Enum):
    MCP = "MCP"
    LLM = "LLM"
    AI_SERVICE = "AI_SERVICE"
    AGENT_MEMORY = "AGENT_MEMORY"
    AUTHENTICATION = "AUTHENTICATION"


class LogLevel(str, Enum):
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    FATAL = "FATAL"


# LogLevel -> Python logging level number. WARN/FATAL are the mandatory
# schema's names for Python's WARNING/CRITICAL; TRACE is the custom level above.
LOG_LEVEL_TO_PYTHON = {
    LogLevel.TRACE: TRACE_LEVEL,
    LogLevel.DEBUG: logging.DEBUG,
    LogLevel.INFO: logging.INFO,
    LogLevel.WARN: logging.WARNING,
    LogLevel.ERROR: logging.ERROR,
    LogLevel.FATAL: logging.CRITICAL,
}


class MCPSubtype(str, Enum):
    MCP_TOOL_LIST = "MCP_TOOL_LIST"
    MCP_TOOL_INVOKE_ENTRY = "MCP_TOOL_INVOKE_ENTRY"
    MCP_TOOL_INVOKE_EXIT = "MCP_TOOL_INVOKE_EXIT"
    MCP_PROMPT_OPERATION = "MCP_PROMPT_OPERATION"
    MCP_RESOURCE_ACCESS = "MCP_RESOURCE_ACCESS"


class LLMSubtype(str, Enum):
    LLM_REQUEST = "LLM_REQUEST"
    LLM_RESPONSE = "LLM_RESPONSE"
    LLM_ERROR = "LLM_ERROR"
    LLM_TOKEN_COUNT = "LLM_TOKEN_COUNT"
    LLM_CACHE_HIT = "LLM_CACHE_HIT"


class AIServiceSubtype(str, Enum):
    AI_SERVICE_ENTRY = "AI_SERVICE_ENTRY"
    AI_SERVICE_EXIT = "AI_SERVICE_EXIT"
    AI_SERVICE_ERROR = "AI_SERVICE_ERROR"
    AI_SERVICE_CLASSIFICATION = "AI_SERVICE_CLASSIFICATION"
    AI_SERVICE_EXTRACTION = "AI_SERVICE_EXTRACTION"


class AgentMemorySubtype(str, Enum):
    MEMORY_READ = "MEMORY_READ"
    MEMORY_WRITE = "MEMORY_WRITE"
    MEMORY_UPDATE = "MEMORY_UPDATE"
    MEMORY_DELETE = "MEMORY_DELETE"
    MEMORY_CLEAR = "MEMORY_CLEAR"


class AuthenticationSubtype(str, Enum):
    AUTH_SUCCESS = "AUTH_SUCCESS"
    AUTH_FAILURE = "AUTH_FAILURE"
    TOKEN_VALIDATION_SUCCESS = "TOKEN_VALIDATION_SUCCESS"
    TOKEN_VALIDATION_FAILURE = "TOKEN_VALIDATION_FAILURE"
    PERMISSION_CHECK_SUCCESS = "PERMISSION_CHECK_SUCCESS"
    PERMISSION_CHECK_FAILURE = "PERMISSION_CHECK_FAILURE"
