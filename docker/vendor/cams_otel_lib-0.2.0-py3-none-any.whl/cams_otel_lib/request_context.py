from uuid import uuid4

_UNSET = (None, "", "N/A")


class RequestContext:
    """Holds per-request information used for structured logging and distributed tracing.

    Attributes whose value is absent or sentinel ('N/A', '') are auto-generated
    (``request_id``, ``agent_instance_id``) or left at ``'N/A'``. All mandatory
    attributes are mirrored into ``extra_logging_attributes`` unconditionally;
    optional attributes are only added when actually set, so unused optional
    fields don't clutter every log line.

    Field names match the mandatory OTEL log schema field-for-field:
    ``agent_id`` identifies the agent itself (e.g. its agent_definition id),
    distinct from ``agent_instance_id`` (the specific running deployment/
    instance of that agent) — callers must pass both, not reuse one for the
    other. ``system_id``/``org_id``/``project_id`` are the decomposed
    organizational scope (system -> org unit -> project); ``scope`` is the
    mandatory dotted-string form ("system.org.project"), auto-computed from
    those three when not passed explicitly. Both representations are kept:
    ``scope`` for schema compliance/display, the separate id fields because a
    single dotted string only supports efficient prefix queries in OpenSearch
    ("everything under this system") — isolating just the org or just the
    project needs slow infix wildcard queries against one field.
    """

    def __init__(
        self,
        request_id: str,
        tenant_id: str,
        app_id: str,
        user_id: str,
        scope: str = "N/A",
        session_id: str = "N/A",
        agent_id: str = "N/A",
        agent_instance_id: str = "N/A",
        system_id: str = "N/A",
        org_id: str = "N/A",
        project_id: str = "N/A",
        retry_count: int = 1,
        agent_harness_id: str = "N/A",
        message_subtype: str = "N/A",
        chat_conversation_id: str = "N/A",
        correlation_id: str = "N/A",
        parent_request_id: str = "N/A",
        knowledge_base_name: str = "N/A",
        service_name: str = "cams",
    ):
        self.request_id = request_id if request_id not in _UNSET else uuid4().hex.lower()
        self.tenant_id = tenant_id
        self.app_id = app_id
        self.user_id = user_id
        self.session_id = session_id
        self.service_name = service_name
        self.agent_id = agent_id if agent_id not in _UNSET else uuid4().hex.lower()
        self.agent_instance_id = (
            agent_instance_id if agent_instance_id not in _UNSET else uuid4().hex.lower()
        )
        self.system_id = system_id
        self.org_id = org_id
        self.project_id = project_id
        if scope not in _UNSET:
            self.scope = scope
        elif system_id not in _UNSET and org_id not in _UNSET and project_id not in _UNSET:
            self.scope = f"{system_id}.{org_id}.{project_id}"
        else:
            self.scope = "N/A"
        self.retry_count = retry_count

        # Optional fields — kept off extra_logging_attributes unless set.
        self.agent_harness_id = agent_harness_id
        self.message_subtype = message_subtype
        self.chat_conversation_id = chat_conversation_id
        self.correlation_id = correlation_id
        self.parent_request_id = parent_request_id
        self.knowledge_base_name = knowledge_base_name

        self.observability_client = None
        self.extra_logging_attributes = {
            "request_id": self.request_id,
            "tenant_id": self.tenant_id,
            "scope": self.scope,
            "app_id": self.app_id,
            "user_id": self.user_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "agent_instance_id": self.agent_instance_id,
            "system_id": self.system_id,
            "org_id": self.org_id,
            "project_id": self.project_id,
            "retry_count": self.retry_count,
        }
        for key, value in (
            ("agent_harness_id", self.agent_harness_id),
            ("message_subtype", self.message_subtype),
            ("chat_conversation_id", self.chat_conversation_id),
            ("correlation_id", self.correlation_id),
            ("parent_request_id", self.parent_request_id),
            ("knowledge_base_name", self.knowledge_base_name),
        ):
            if value not in _UNSET:
                self.extra_logging_attributes[key] = value
