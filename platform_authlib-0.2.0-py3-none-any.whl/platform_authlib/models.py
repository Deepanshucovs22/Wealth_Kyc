"""Domain models for the authlib package.

Provides immutable data structures representing auth grants, authenticated
users, and permission-binding entries.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class ScopeChainEntry:
    """A single node in the scope hierarchy chain embedded in a JWT grant.

    Attributes:
        scope_type: Application-defined type name derived from the first dot-segment
            of the scope pattern (e.g. ``"System"``, ``"Org"``).
        id: UUID of the concrete scope entity at this level.
    """

    scope_type: str
    id: str


@dataclass(frozen=True)
class Grant:
    """A single authorization grant carrying a role and an optional scope.

    Resources are no longer embedded in the JWT — they are resolved
    server-side from the auth-service role-resource cache on every
    /auth/check call.

    Attributes:
        role: Human-readable role name (e.g. ``"editor"``).
        scope: Scope pattern this grant is constrained to.  Present as metadata
            only — auth-service pre-filters grants to the active scope at mint
            time, so authlib does not need to re-evaluate this field.
        scope_chain: Ordered ancestry from root to the active scope, baked into
            the JWT at mint time.  Empty when the grant is not scope-constrained.
    """

    role: str
    scope: str | None = None
    scope_chain: tuple[ScopeChainEntry, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class AuthenticatedUser:
    """A fully-validated principal produced after token verification and grant loading.

    Attributes:
        user_id: Unique identifier of the user within the platform (string form
            of the numeric database ID).
        tenant_id: Numeric identifier of the tenant the user belongs to.
        app_id: Application the token was issued for.
        email: User's primary email address.
        jti: JWT ID — used for revocation checks.
        session_id: Opaque session handle issued at login; stable across refreshes.
        active_scope: The scope pattern the user is currently operating under
            (e.g. ``"Org.Finance"``).  Empty string when no scope is active.
        exp: Unix timestamp at which the JWT expires.
        iat: Unix timestamp at which the JWT was issued.
        grants: Ordered tuple of :class:`Grant` objects assigned to this user.
            Already pre-filtered by auth-service to the active scope at mint time.
    """

    user_id: str
    tenant_id: int
    app_id: str
    email: str
    jti: str
    session_id: str
    active_scope: str
    grants: tuple[Grant, ...]
    exp: int = 0
    iat: int = 0

    def has_role(self, role: str) -> bool:
        """Return True if any grant carries *role*.

        Args:
            role: The role name to check (e.g. ``"editor"``).

        Returns:
            ``True`` if at least one grant matches, else ``False``.
        """
        return any(grant.role == role for grant in self.grants)


@dataclass
class BindingEntry:
    """A single HTTP-path-to-permission binding fetched from the auth service.

    Attributes:
        permission_name: Permission required to access this path.
        http_method: HTTP verb (e.g. ``"GET"``), or ``"*"`` for any method.
        path_pattern: Raw path pattern, possibly containing ``{param}`` placeholders.
        pattern_type: One of ``"exact"``, ``"parameterized"``, or ``"glob"``.
            Auth-service emits ``"parameterized"`` for paths with ``{param}``
            placeholders; ``"param"`` is also accepted for compatibility.
        priority: Higher numbers are evaluated first during resolution.
        compiled_re: Pre-compiled regex for parameterized/glob patterns; excluded
            from equality/hash comparisons.
    """

    permission_name: str
    http_method: str
    path_pattern: str
    pattern_type: str
    priority: int
    compiled_re: re.Pattern[str] | None = field(default=None, compare=False)
