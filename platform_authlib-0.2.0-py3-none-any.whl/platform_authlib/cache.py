"""Two-layer token/binding cache.

Provides a combined L1 (in-process TTLCache) and optional L2 (Memcached via
pymemcache PooledClient) cache for auth objects.  All cache misses fall through
transparently; L2 is best-effort and its absence is not an error.
"""

from __future__ import annotations

from typing import Any

import structlog
from cachetools import TTLCache

log = structlog.get_logger(__name__)

_DEFAULT_L1_MAXSIZE = 1024
_DEFAULT_L1_TTL = 300  # seconds


class TwoLayerCache:
    """In-process TTLCache backed by an optional Memcached pool.

    Args:
        memcached_servers: Optional sequence of ``(host, port)`` tuples passed
            to :class:`pymemcache.client.PooledClient`.  When ``None`` or empty
            only L1 is used.
        l1_maxsize: Maximum number of items held in the in-process cache.
            Defaults to ``1024``.
        l1_ttl: Time-to-live in seconds for L1 entries.  Defaults to ``300``.
    """

    def __init__(
        self,
        memcached_servers: list[tuple[str, int]] | None = None,
        l1_maxsize: int = _DEFAULT_L1_MAXSIZE,
        l1_ttl: int = _DEFAULT_L1_TTL,
    ) -> None:
        """Initialise both cache layers."""
        self._l1: TTLCache = TTLCache(maxsize=l1_maxsize, ttl=l1_ttl)
        self._l2: Any = None

        if memcached_servers:
            try:
                from pymemcache.client.base import PooledClient  # type: ignore[import-untyped]

                # pymemcache PooledClient accepts a single server tuple or a list for
                # the HashClient.  We keep it simple: use the first server for a
                # single-node setup; consumers that need cluster support should
                # subclass or pass a HashClient instance.
                from pymemcache import serde as pymemcache_serde  # type: ignore[import-untyped]

                server = memcached_servers[0] if len(memcached_servers) == 1 else None
                if server:
                    self._l2 = PooledClient(server, serde=pymemcache_serde.pickle_serde)
                else:
                    from pymemcache.client.hash import HashClient  # type: ignore[import-untyped]

                    self._l2 = HashClient(memcached_servers, serde=pymemcache_serde.pickle_serde)
                log.info(
                    "authlib.cache.memcached_connected",
                    servers=memcached_servers,
                )
            except Exception as exc:
                log.warning(
                    "authlib.cache.memcached_init_failed",
                    error=str(exc),
                )
                self._l2 = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, key: str) -> Any | None:
        """Return the cached value for *key*, checking L1 then L2.

        A hit in L2 promotes the value back into L1 so subsequent reads are fast.

        Args:
            key: Cache key string.

        Returns:
            Cached value, or ``None`` if the key is absent from both layers.
        """
        value = self._l1.get(key)
        if value is not None:
            return value

        if self._l2 is not None:
            try:
                value = self._l2.get(key)
                if value is not None:
                    self._l1[key] = value
            except Exception as exc:
                log.warning("authlib.cache.l2_get_error", key=key, error=str(exc))

        return value

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Store *value* under *key* in both cache layers.

        Args:
            key: Cache key string.
            value: Value to store.  Must be serialisable by pymemcache when L2
                is enabled.
            ttl: Time-to-live in seconds for the L2 entry.  L1 TTL is fixed at
                construction time.  When ``None`` the L2 entry has no expiry.
        """
        self._l1[key] = value

        if self._l2 is not None:
            try:
                self._l2.set(key, value, expire=ttl or 0)
            except Exception as exc:
                log.warning("authlib.cache.l2_set_error", key=key, error=str(exc))

    def delete(self, key: str) -> None:
        """Remove *key* from both cache layers.

        Args:
            key: Cache key string to evict.
        """
        self._l1.pop(key, None)

        if self._l2 is not None:
            try:
                self._l2.delete(key)
            except Exception as exc:
                log.warning("authlib.cache.l2_delete_error", key=key, error=str(exc))

    def close(self) -> None:
        """Release L2 Memcached connections.

        Safe to call even when L2 is not configured.
        """
        if self._l2 is not None:
            try:
                self._l2.close()
            except Exception as exc:
                log.warning("authlib.cache.close_error", error=str(exc))
