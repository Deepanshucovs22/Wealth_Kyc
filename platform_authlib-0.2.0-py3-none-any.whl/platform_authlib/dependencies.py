"""FastAPI dependency functions for auth enforcement.

Provides two reusable dependency factories:

- :func:`get_current_user` — injects the authenticated user or raises HTTP 401.
- :func:`require_permission_check` — factory that returns a Depends that checks
  a specific permission at request time (runtime check inside the handler).

Usage::

    from fastapi import FastAPI, Depends
    from platform_authlib import get_current_user, require_permission_check
    from platform_authlib.models import AuthenticatedUser

    app = FastAPI()

    @app.get("/profile")
    async def profile(user: AuthenticatedUser = Depends(get_current_user)):
        return {"user_id": user.user_id}

    @app.get("/reports")
    async def reports(
        _: None = Depends(require_permission_check("reports:read")),
        user: AuthenticatedUser = Depends(get_current_user),
    ):
        return {"reports": []}
"""

from __future__ import annotations

from typing import Callable

import structlog
from fastapi import HTTPException, Request

from .models import AuthenticatedUser

log = structlog.get_logger(__name__)


async def get_current_user(request: Request) -> AuthenticatedUser:
    """FastAPI dependency that returns the authenticated user attached to *request*.

    :class:`~authlib.middleware.AuthEnforcementMiddleware` must be mounted on
    the application for ``request.state.user`` to be populated.

    Args:
        request: Injected by FastAPI's dependency injection system.

    Returns:
        The :class:`~authlib.models.AuthenticatedUser` for the current request.

    Raises:
        HTTPException: 401 if no authenticated user is present on the request state.
    """
    user: AuthenticatedUser | None = getattr(request.state, "user", None)
    if user is None:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


def require_permission_check(permission: str) -> Callable:
    """Return a FastAPI Depends callable that checks a permission at request time.

    Use this when you need a runtime permission check inside a handler beyond
    what the binding table enforces via the middleware.  The middleware already
    enforces permissions automatically for all bound routes — use this only as
    an additional in-handler check when needed.

    Unlike :func:`get_current_user`, this factory must be called with the
    required permission string at *route definition time* and the resulting
    callable passed to ``Depends``::

        Depends(require_permission_check("documents:write"))

    Args:
        permission: Permission string the user must possess (e.g. ``"reports:read"``).

    Returns:
        An async callable suitable for use as a FastAPI dependency.

    Raises:
        HTTPException: 401 if no user is attached to the request state.
        HTTPException: 403 if the user lacks the required permission.
    """

    async def _check(request: Request) -> AuthenticatedUser:
        user: AuthenticatedUser | None = getattr(request.state, "user", None)
        if user is None:
            raise HTTPException(status_code=401, detail="Not authenticated")

        if not user.has_permission(permission):
            log.info(
                "authlib.dependencies.permission_denied",
                user_id=user.user_id,
                required_permission=permission,
            )
            raise HTTPException(
                status_code=403,
                detail=f"Permission '{permission}' is required",
            )

        return user

    return _check
