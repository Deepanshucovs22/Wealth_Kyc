"""FastAPI lifespan helper for wiring an :class:`~authlib.client.AuthClient`
into a Starlette/FastAPI application.

Usage example::

    from contextlib import asynccontextmanager
    from fastapi import FastAPI
    from platform_authlib import setup_auth
    from platform_authlib.client import AuthClient

    auth = AuthClient(auth_service_url="https://auth.example.com", app_id="my-app")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await setup_auth(auth, app)
        yield
        await auth.close()

    app = FastAPI(lifespan=lifespan)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from .client import AuthClient

log = structlog.get_logger(__name__)


async def setup_auth(auth: "AuthClient", app: Any, coverage_check: str = "warn") -> None:
    """Initialise *auth*, attach it to *app*.state, and optionally run the route coverage check.

    Calls :meth:`~authlib.client.AuthClient.initialize`, stores the client on
    ``app.state.auth``, then — unless *coverage_check* is ``"off"`` — fetches the
    binding table and calls :func:`~authlib.coverage.check_coverage` to flag any
    FastAPI routes that have no binding entry and are not declared as public paths.

    Args:
        auth: An uninitialised :class:`~authlib.client.AuthClient` instance.
        app: A Starlette or FastAPI application object that exposes a
            ``.state`` attribute.
        coverage_check: Controls route-coverage checking on startup.
            ``"warn"`` (default) logs a warning for each uncovered route.
            ``"error"`` raises :class:`RuntimeError` if any uncovered routes are found.
            ``"off"`` disables the check entirely.
    """
    await auth.initialize()
    app.state.auth = auth

    # Run coverage check if enabled
    if coverage_check != "off":
        from platform_authlib.coverage import check_coverage
        bt = await auth.get_binding_table()
        check_coverage(app, bt, mode=coverage_check)

    log.info(
        "authlib.lifespan.setup_done",
        app_id=auth._app_id,
        coverage_check=coverage_check,
    )
