"""FastAPI / Starlette enforcement middleware.

:class:`AuthEnforcementMiddleware` sits in front of every handler and enforces
authentication and permission checks by delegating to the auth service via a
single ``POST /auth/check`` call per request.

Apps are dumb: no local binding table, no JWKS cache, no revocation set.
All auth logic is centralized in the auth service.

Usage::

    from fastapi import FastAPI
    from platform_authlib.middleware import AuthEnforcementMiddleware

    app = FastAPI(...)
    app.add_middleware(AuthEnforcementMiddleware)
"""

from __future__ import annotations

import structlog
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.types import ASGIApp

from .client import (
    AuthServiceUnavailableError,
    NoBindingError,
    PermissionDeniedError,
    TokenExpiredError,
    TokenInvalidError,
    TokenRevokedError,
)

log = structlog.get_logger(__name__)

_BEARER_PREFIX = "Bearer "
_AUTH_HEADER = "Authorization"

# Paths that are always served without auth — Swagger UI, health probes, static assets.
# These are internal/dev paths that carry no sensitive data and have no RBAC binding.
_BYPASS_PATHS = (
    "/docs",
    "/redoc",
    "/openapi.json",
    "/favicon.ico",
    "/health",
    "/",
)
_BYPASS_PREFIXES = (
    "/docs/",
    "/health/",
)


class AuthEnforcementMiddleware(BaseHTTPMiddleware):
    """ASGI middleware that enforces auth on every request via the auth service.

    Per-request flow:

    1. Retrieve the :class:`~authlib.client.AuthClient` from ``request.app.state.auth``.
    2. Extract the Bearer token from the ``Authorization`` header.
       Return **401** if absent.
    3. Call :meth:`~authlib.client.AuthClient.check` with token + method + path.
       The auth service validates the JWT, checks revocation, resolves the binding
       table, and evaluates RBAC in one call.
    4. On success, attach ``request.state.user`` for downstream handlers.
    5. On denial, return the appropriate 401 / 403 response.

    Public paths (health, login, etc.) are handled transparently by the auth
    service — it returns ``allowed: true`` for public paths even without a token.
    The middleware passes an empty token string for requests without an
    Authorization header so the auth service can still serve public paths.

    Args:
        app: The wrapped ASGI application.
    """

    def __init__(
        self,
        app: ASGIApp,
        auth_client=None,
        allowed_tenant_ids: list[int] | None = None,
    ) -> None:
        super().__init__(app)
        self._auth_client_override = auth_client
        from .platform_isolation import build_tenant_allowlist
        self._allowed_tenants = (
            build_tenant_allowlist(allowed_tenant_ids) if allowed_tenant_ids else None
        )

    async def dispatch(self, request: Request, call_next) -> Response:
        """Enforce auth on *request* before passing it to *call_next*."""
        auth_state = getattr(getattr(request, "app", None), "state", None)
        auth_client = (
            self._auth_client_override
            or (getattr(auth_state, "auth", None) if auth_state is not None else None)
        )

        if auth_client is None:
            log.error("authlib.middleware.no_client")
            return JSONResponse({"error": "Auth client not configured"}, status_code=500)

        path = request.url.path
        if path in _BYPASS_PATHS or any(path.startswith(p) for p in _BYPASS_PREFIXES):
            return await call_next(request)

        token = _extract_token(request) or ""

        try:
            user = await auth_client.check(token, request.method, path)
        except AuthServiceUnavailableError as exc:
            log.error("authlib.middleware.auth_service_unavailable", error=str(exc))
            return JSONResponse(
                {
                    "error": "auth_service_unavailable",
                    "message": "Authentication service is temporarily unavailable. Please try again shortly.",
                },
                status_code=503,
            )
        except TokenExpiredError:
            return JSONResponse(
                {"error": "token_expired", "message": "Your session has expired. Please sign in again."},
                status_code=401,
            )
        except TokenRevokedError:
            return JSONResponse(
                {"error": "token_revoked", "message": "Your session has been revoked. Please sign in again."},
                status_code=401,
            )
        except TokenInvalidError:
            if not token:
                return JSONResponse(
                    {"error": "token_missing", "message": "Authentication required."},
                    status_code=401,
                )
            return JSONResponse(
                {"error": "token_invalid", "message": "Your session is invalid. Please sign in again."},
                status_code=401,
            )
        except PermissionDeniedError as exc:
            log.info(
                "authlib.middleware.forbidden",
                required=exc.required_permission,
                path=path,
            )
            return JSONResponse(
                {
                    "error": "insufficient_permissions",
                    "message": (
                        f"You don't have the required role/permission "
                        f"('{exc.required_permission}') to use this resource. "
                        "Contact your admin to request access."
                    ),
                    "required_permission": exc.required_permission,
                },
                status_code=403,
            )
        except NoBindingError:
            return JSONResponse(
                {"error": "forbidden", "message": "This endpoint is not accessible."},
                status_code=403,
            )
        except Exception as exc:
            log.error("authlib.middleware.check_error", error=str(exc))
            return JSONResponse(
                {"error": "authentication_error", "message": "Authentication failed. Please sign in again."},
                status_code=401,
            )

        # Platform tenant isolation (optional allowlist)
        if self._allowed_tenants is not None:
            from .platform_isolation import check_tenant_allowed
            if not check_tenant_allowed({"tenant_id": user.tenant_id}, self._allowed_tenants):
                return JSONResponse({"error": "Tenant not permitted"}, status_code=403)

        request.state.user = user
        request.state.scope = user.active_scope or None

        return await call_next(request)


def require_permission(permission: str):
    """Decorator for FastAPI route handlers that declares an explicit required permission.

    Used by the coverage checker at startup to verify route coverage.

    Usage::

        @router.get("/transcripts/{id}/summary")
        @require_permission("transcripts:read")
        async def transcript_summary(id: str, ...):
            ...
    """
    def decorator(func):
        func._required_permission = permission
        return func
    return decorator


def no_auth(func):
    """Decorator that marks a route as exempt from :class:`AuthEnforcementMiddleware`.

    Usage::

        @router.post("/webhooks/stripe")
        @no_auth
        async def stripe_webhook(request: Request):
            verify_stripe_signature(request)
    """
    func._no_auth = True
    return func


def _extract_token(request: Request) -> str | None:
    """Extract a Bearer token from the Authorization header."""
    auth_header: str | None = request.headers.get(_AUTH_HEADER)
    if auth_header and auth_header.startswith(_BEARER_PREFIX):
        return auth_header[len(_BEARER_PREFIX):]
    return None
