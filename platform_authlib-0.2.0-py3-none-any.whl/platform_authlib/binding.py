"""HTTP-path-to-permission binding resolution.

Fetches binding rules from the auth service and resolves incoming HTTP
requests to required permission names.  Public path detection is also
handled here.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

import structlog

from .models import BindingEntry

if TYPE_CHECKING:
    import httpx

log = structlog.get_logger(__name__)

# URL template for the binding table endpoint.
# The {app_id} token is replaced at call time.
_BINDINGS_PATH_TMPL = "/api/v1/apps/{app_id}/bindings"


def _compile_pattern(path_pattern: str) -> re.Pattern[str]:
    """Convert an ``{param}``-style path template into a named-group regex.

    Each ``{name}`` placeholder is replaced with a named capture group
    ``(?P<name>[^/]+)`` so that parameter values can be extracted if needed.
    The result is anchored at both ends.

    Args:
        path_pattern: URL path template such as ``"/users/{user_id}/profile"``.

    Returns:
        Compiled :class:`re.Pattern` anchored to the full path string.
    """
    escaped = re.sub(
        r"\{([^}]+)\}",
        lambda m: f"(?P<{m.group(1)}>[^/]+)",
        re.escape(path_pattern).replace(r"\{", "{").replace(r"\}", "}"),
    )
    return re.compile(f"^{escaped}$")


class BindingTable:
    """Resolved snapshot of all HTTP-to-permission bindings for one application.

    Bindings are partitioned internally into three buckets for efficient lookup:
    - **exact**: ``path_pattern`` has no placeholders or wildcards.
    - **param**: ``path_pattern`` contains ``{name}`` placeholders.
    - **glob**: all remaining patterns (treated as regex globs).

    Param and glob lists are sorted by ``priority`` descending so the most
    specific rule wins on the first match.

    Args:
        bindings: All :class:`~authlib.models.BindingEntry` objects for the app.
        public_paths: Path strings that require no authentication.
        default_policy: ``"allow"`` or ``"deny"`` — applied when no binding matches.
    """

    def __init__(
        self,
        bindings: list[BindingEntry],
        public_paths: list[str],
        default_policy: str = "deny",
        tenant_id: int = 0,
    ) -> None:
        """Initialise bucket structures from raw binding and public-path lists."""
        self._default_policy = default_policy
        self.tenant_id: int = tenant_id

        # Permission binding buckets
        self._exact: dict[tuple[str, str], str] = {}
        self._param: list[BindingEntry] = []
        self._glob: list[BindingEntry] = []

        for entry in bindings:
            if entry.pattern_type == "exact":
                self._exact[(entry.http_method.upper(), entry.path_pattern)] = (
                    entry.permission_name
                )
            elif entry.pattern_type in ("param", "parameterized"):
                compiled = _compile_pattern(entry.path_pattern)
                self._param.append(
                    BindingEntry(
                        permission_name=entry.permission_name,
                        http_method=entry.http_method,
                        path_pattern=entry.path_pattern,
                        pattern_type=entry.pattern_type,
                        priority=entry.priority,
                        compiled_re=compiled,
                    )
                )
            else:
                compiled = _compile_pattern(entry.path_pattern)
                self._glob.append(
                    BindingEntry(
                        permission_name=entry.permission_name,
                        http_method=entry.http_method,
                        path_pattern=entry.path_pattern,
                        pattern_type=entry.pattern_type,
                        priority=entry.priority,
                        compiled_re=compiled,
                    )
                )

        self._param.sort(key=lambda e: e.priority, reverse=True)
        self._glob.sort(key=lambda e: e.priority, reverse=True)

        # Public path buckets
        self._public_exact: set[str] = set()
        self._public_param: list[re.Pattern[str]] = []

        for path in public_paths:
            if "{" in path:
                self._public_param.append(_compile_pattern(path))
            else:
                self._public_exact.add(path)

    @property
    def default_policy(self) -> str:
        """The fallback policy (``"allow"`` or ``"deny"``) when no binding matches."""
        return self._default_policy

    def resolve(self, method: str, path: str) -> str | None:
        """Return the permission name required for *method* on *path*, or ``None``.

        Resolution order:
        1. Exact match on ``(METHOD, path)``.
        2. Param patterns — scanned in descending priority order; the first
           entry whose method matches (or is ``"*"``) and whose regex matches
           *path* wins.
        3. Glob patterns — same scan logic.

        Args:
            method: HTTP verb (e.g. ``"GET"``).
            path: Request path (e.g. ``"/users/42/profile"``).

        Returns:
            Permission name string, or ``None`` if no binding matches.
        """
        upper_method = method.upper()

        # 1. Exact
        perm = self._exact.get((upper_method, path)) or self._exact.get(("*", path))
        if perm is not None:
            return perm

        # 2. Param
        for entry in self._param:
            if entry.http_method not in (upper_method, "*"):
                continue
            if entry.compiled_re and entry.compiled_re.match(path):
                return entry.permission_name

        # 3. Glob
        for entry in self._glob:
            if entry.http_method not in (upper_method, "*"):
                continue
            if entry.compiled_re and entry.compiled_re.match(path):
                return entry.permission_name

        return None

    def is_public(self, method: str, path: str) -> bool:  # noqa: ARG002
        """Return ``True`` if *path* is listed as a public (unauthenticated) path.

        The ``method`` argument is accepted for API symmetry but public paths are
        currently method-agnostic.

        Args:
            method: HTTP verb (unused, reserved for future method-scoped public paths).
            path: Request path to test.

        Returns:
            ``True`` when *path* matches a public-path rule.
        """
        if path in self._public_exact:
            return True
        return any(pattern.match(path) for pattern in self._public_param)

    @classmethod
    def from_response(cls, payload: dict) -> "BindingTable":
        """Build a :class:`BindingTable` from a pre-fetched binding table response dict.

        Used by :meth:`~authlib.client.AuthClient.get_binding_table` which owns
        the HTTP call and passes the parsed JSON here.

        Args:
            payload: Parsed JSON from ``GET /api/v1/apps/{app_id}/bindings``.

        Returns:
            A fully-initialised :class:`BindingTable`.
        """
        from .models import BindingEntry

        raw_bindings: list[dict] = payload.get("bindings") or []
        raw_public: list[dict] = payload.get("public_paths") or []
        resolved_policy: str = payload.get("default_policy") or "deny"
        tenant_id: int = int(payload.get("tenant_id") or 0)

        entries = []
        for b in raw_bindings:
            perm_name = b.get("resource_name", "")
            if not perm_name:
                log.warning(
                    "authlib.binding.missing_resource_name",
                    binding=b.get("binding_id", "<unknown>"),
                )
                continue
            entries.append(BindingEntry(
                permission_name=perm_name,
                http_method=b.get("http_method", "*"),
                path_pattern=b.get("path_pattern", ""),
                pattern_type=b.get("pattern_type", "exact"),
                priority=b.get("priority", 0),
            ))

        public_paths = [
            path for path in (
                p.get("path", "") if isinstance(p, dict) else p
                for p in raw_public
            )
            if path
        ]

        log.info(
            "authlib.binding.from_response",
            binding_count=len(entries),
            public_count=len(public_paths),
            manifest_version=payload.get("manifest_version", ""),
        )
        return cls(entries, public_paths, resolved_policy, tenant_id=tenant_id)

    @classmethod
    async def fetch(
        cls,
        http: "httpx.AsyncClient",
        app_id: str,
        default_policy: str = "deny",
    ) -> "BindingTable":
        """Fetch the binding table from the auth service via a single GET request.

        Calls ``GET /api/v1/apps/{app_id}/bindings`` which returns a
        ``BindingTableResponse`` object containing both the HTTP bindings and
        the public (unauthenticated) paths in one response.

        Args:
            http: Shared :class:`httpx.AsyncClient` pointed at the auth service base URL.
            app_id: Application identifier used as a URL path parameter.
            default_policy: Fallback policy when no binding matches; overridden
                by the ``default_policy`` field in the auth service response if present.

        Returns:
            A fully-initialised :class:`BindingTable`.

        Raises:
            httpx.HTTPStatusError: If the upstream request returns a non-2xx response.
        """
        log.info("authlib.binding.fetch_start", app_id=app_id)

        url = _BINDINGS_PATH_TMPL.format(app_id=app_id)
        resp = await http.get(url)
        resp.raise_for_status()

        payload: dict = resp.json()

        # The auth service returns a BindingTableResponse object with keys:
        #   bindings, public_paths, default_policy, app_id, manifest_version
        raw_bindings: list[dict] = payload.get("bindings") or []
        raw_public: list[dict] = payload.get("public_paths") or []
        resolved_policy: str = payload.get("default_policy") or default_policy
        tenant_id: int = int(payload.get("tenant_id") or 0)

        entries = []
        for b in raw_bindings:
            perm_name = b.get("resource_name", "")
            if not perm_name:
                log.warning(
                    "authlib.binding.missing_resource_name",
                    binding=b.get("binding_id", "<unknown>"),
                )
                continue

            entries.append(BindingEntry(
                permission_name=perm_name,
                http_method=b.get("http_method", "*"),
                path_pattern=b.get("path_pattern", ""),
                pattern_type=b.get("pattern_type", "exact"),
                priority=b.get("priority", 0),
            ))

        # public_paths entries from BindingTableResponse are dicts with
        # "method" and "path" keys.  Extract the path strings only; the
        # BindingTable.is_public check is method-agnostic, which is correct
        # because public paths (health, version, login) accept all methods.
        public_paths = [
            path for path in (
                p.get("path", "") if isinstance(p, dict) else p
                for p in raw_public
            )
            if path
        ]

        log.info(
            "authlib.binding.fetch_done",
            app_id=app_id,
            binding_count=len(entries),
            public_count=len(public_paths),
            manifest_version=payload.get("manifest_version", ""),
        )
        return cls(entries, public_paths, resolved_policy, tenant_id=tenant_id)
