"""Platform tenant JWT isolation (D12-F8).

When a consumer app is configured with a set of allowed tenant IDs,
the AuthEnforcementMiddleware will reject JWTs from tenants not in that set.
This prevents platform-tenant (is_platform_tenant=true) JWTs from being
accepted by normal product applications.
"""

import structlog
from typing import FrozenSet

log = structlog.get_logger(__name__)


def build_tenant_allowlist(allowed_tenant_ids: list[int]) -> FrozenSet[int]:
    """Build an immutable frozenset of allowed tenant IDs for JWT isolation."""
    return frozenset(allowed_tenant_ids)


def check_tenant_allowed(claims: dict, allowed_tenants: FrozenSet[int] | None) -> bool:
    """Return True if the JWT tenant_id is in the allowed set (or no allowlist is configured).

    Args:
        claims: Decoded JWT claims dict containing tenant_id.
        allowed_tenants: Frozenset of permitted tenant IDs. None means all tenants allowed.

    Returns:
        True if the tenant is allowed; False if it should be rejected.
    """
    if allowed_tenants is None:
        return True
    tenant_id = claims.get("tenant_id")
    if tenant_id is None:
        log.warning("platform_isolation.missing_tenant_id")
        return False
    allowed = int(tenant_id) in allowed_tenants
    if not allowed:
        log.warning(
            "platform_isolation.tenant_rejected",
            tenant_id=tenant_id,
            reason="not in allowed tenant list",
        )
    return allowed
