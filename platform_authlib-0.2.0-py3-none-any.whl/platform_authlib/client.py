"""Central auth client that calls the auth service for every request check.

:class:`AuthClient` is the primary entry point for consumer applications.
It is typically created once at startup, initialised via :meth:`initialize`,
and torn down via :meth:`close` in a lifespan handler.

Architecture: apps are dumb — all auth logic lives in the auth service.
Every request sends ``POST /auth/check`` with the token + method + path.
The auth service validates the JWT, checks revocation, resolves the binding
table, and evaluates RBAC — returning a single allowed/denied decision.
Apps do not maintain local binding tables, JWKS caches, or revocation sets.
"""

from __future__ import annotations

import httpx
import structlog

from .binding import BindingTable
from .models import AuthenticatedUser, Grant, ScopeChainEntry
from .tracing import make_tracing_client

log = structlog.get_logger(__name__)

_CHECK_PATH = "/auth/check"
_BINDINGS_PATH_TMPL = "/api/v1/apps/{app_id}/bindings"
_HEALTH_PATH = "/health/ready"


class AuthClient:
    """Async auth client that delegates all auth decisions to the auth service.

    Per-request flow:
        App middleware calls :meth:`check` with the raw token + HTTP method + path.
        Auth service validates, checks revocation, resolves permission, evaluates RBAC.
        Returns an :class:`~authlib.models.AuthenticatedUser` on success or raises.

    No local binding table, no JWKS cache, no revocation set — all centralized.

    Args:
        auth_service_url: Base URL of the Covasant auth service (no trailing slash).
        app_id: Application identifier; scopes all upstream requests.
    """

    def __init__(
        self,
        auth_service_url: str,
        app_id: str,
    ) -> None:
        """Store configuration; I/O initialisation happens in :meth:`initialize`."""
        self._auth_service_url = auth_service_url.rstrip("/")
        self._app_id = app_id
        self._http = make_tracing_client(self._auth_service_url, timeout=10.0)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def initialize(self) -> None:
        """Verify connectivity to the auth service.

        Performs a health check so startup fails fast if the auth service is
        unreachable, rather than failing silently on the first real request.
        """
        healthy = await self.health_check()
        if not healthy:
            log.warning(
                "authlib.client.auth_service_unreachable",
                auth_service_url=self._auth_service_url,
            )

        log.info(
            "authlib.client.initialized",
            app_id=self._app_id,
            auth_service_url=self._auth_service_url,
        )

    async def close(self) -> None:
        """Release all I/O resources.

        Safe to call even if :meth:`initialize` was never called.
        """
        await self._http.aclose()
        log.info("authlib.client.closed", app_id=self._app_id)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def check(
        self,
        token: str,
        method: str,
        path: str,
    ) -> AuthenticatedUser:
        """Validate *token* and check whether the caller may perform *method* on *path*.

        Sends ``POST /auth/check`` to the auth service with the token, app_id,
        method, and path.  The auth service performs all validation and RBAC
        evaluation centrally and returns a single decision.

        Args:
            token: Raw Bearer token string from the Authorization header.
            method: HTTP verb (e.g. ``"GET"``).
            path: Request path (e.g. ``"/api/v1/environments"``).

        Returns:
            :class:`~authlib.models.AuthenticatedUser` when the token is valid
            and the caller is authorised.

        Raises:
            AuthCheckError: Base class for all auth failures.
            TokenExpiredError: Token has expired.
            TokenRevokedError: Token has been revoked (logged out).
            TokenInvalidError: Token is malformed or signature invalid.
            PermissionDeniedError: Token is valid but lacks required permission.
            NoBindingError: No binding registered for this method+path.
        """
        payload = {
            "token": token,
            "app_id": self._app_id,
            "method": method,
            "path": path,
        }

        # DS-5: never log the raw token — log only its length/presence so we
        # can tell "empty token" apart from "token present" without exposing it.
        log.debug(
            "authlib.client.check.request",
            url=f"{self._auth_service_url}{_CHECK_PATH}",
            app_id=self._app_id,
            method=method,
            path=path,
            token_len=len(token) if token else 0,
            token_present=bool(token),
        )

        try:
            response = await self._http.post(_CHECK_PATH, json=payload)
        except httpx.HTTPError as exc:
            # Genuine network-level failure: DNS, connection refused, timeout,
            # TLS error, etc. — the auth service was never actually reached.
            log.error(
                "authlib.client.auth_service_unreachable",
                error=str(exc),
                error_type=type(exc).__name__,
                method=method,
                path=path,
            )
            raise AuthServiceUnavailableError(
                f"Auth service unreachable: {exc}"
            ) from exc

        log.debug(
            "authlib.client.check.response",
            status_code=response.status_code,
            body=response.text,
            method=method,
            path=path,
        )

        if response.status_code >= 500:
            # Auth service itself is unhealthy — treat as unavailable, not a
            # 400-class auth failure, so middleware returns 503 instead of 401.
            log.error(
                "authlib.client.auth_service_error",
                status_code=response.status_code,
                body=response.text,
                method=method,
                path=path,
            )
            raise AuthServiceUnavailableError(
                f"Auth service returned {response.status_code}: {response.text}"
            )

        if response.status_code == 400:
            # A 400 here means auth-service rejected the shape of our own
            # request (missing/empty app_id, method, or path, or malformed
            # JSON) — a client-side bug in what we sent, not an auth failure
            # and not a connectivity problem. Log the exact payload we built
            # (minus the raw token) and the exact body auth-service returned
            # so the mismatch is diagnosable from these logs alone.
            log.error(
                "authlib.client.check.bad_request",
                status_code=response.status_code,
                body=response.text,
                sent_app_id=self._app_id,
                sent_method=method,
                sent_path=path,
                sent_token_present=bool(token),
            )
            raise TokenInvalidError(
                f"Auth service rejected the check request: {response.text}"
            )

        result: dict = response.json()

        if not result.get("allowed", False):
            reason = result.get("reason", "token_invalid")
            # auth-service's CheckResult sends the denied resource under
            # "required_resource" (e.g. "agentruntime.deployed_agent.invoke"),
            # not "required_permission" — that key never existed in the
            # response, so reading it always silently returned "".
            required = result.get("required_resource", "")
            _raise_for_reason(reason, required)

        return AuthenticatedUser(
            user_id=str(result.get("user_id", "")),
            tenant_id=int(result.get("tenant_id", 0)),
            app_id=result.get("app_id", self._app_id),
            email=result.get("email", ""),
            jti=result.get("jti", ""),
            session_id=result.get("session_id", ""),
            active_scope=result.get("active_scope_id", "") or result.get("active_scope", ""),
            exp=int(result.get("exp", 0)),
            iat=int(result.get("iat", 0)),
            grants=_parse_grants(result.get("grants") or []),
        )

    async def get_binding_table(self) -> BindingTable:
        """Fetch the binding table from the auth service.

        Used only at startup for the route coverage check.  Apps do NOT use
        this for per-request auth — that goes through :meth:`check`.

        Returns:
            A :class:`~authlib.binding.BindingTable` instance.
        """
        url = _BINDINGS_PATH_TMPL.format(app_id=self._app_id)
        resp = await self._http.get(url)
        resp.raise_for_status()
        return BindingTable.from_response(resp.json())

    async def health_check(self) -> bool:
        """Check whether the auth service is reachable and ready.

        Returns:
            ``True`` if the service responds with HTTP 200, ``False`` otherwise.
        """
        try:
            response = await self._http.get(_HEALTH_PATH)
            return response.status_code == 200
        except Exception as exc:
            log.warning("authlib.client.health_check_failed", error=str(exc))
            return False


def _parse_grants(raw_grants: list) -> tuple:
    """Convert the raw grants list from /auth/check into Grant objects."""
    grants = []
    for g in raw_grants:
        chain = tuple(
            ScopeChainEntry(scope_type=e.get("scope_type", ""), id=e.get("id", ""))
            for e in (g.get("scope_chain") or [])
        )
        grants.append(Grant(
            role=g.get("role", ""),
            scope=g.get("scope"),
            scope_chain=chain,
        ))
    return tuple(grants)


# ------------------------------------------------------------------
# Error hierarchy
# ------------------------------------------------------------------

class AuthCheckError(Exception):
    """Base class for all errors returned by :meth:`AuthClient.check`."""


class AuthServiceUnavailableError(AuthCheckError):
    """The auth service is unreachable or returned a 5xx response."""


class TokenExpiredError(AuthCheckError):
    """The JWT has passed its expiry time."""


class TokenRevokedError(AuthCheckError):
    """The JWT has been explicitly revoked (logged out)."""


class TokenInvalidError(AuthCheckError):
    """The JWT is malformed, has an invalid signature, or is otherwise unacceptable."""


class PermissionDeniedError(AuthCheckError):
    """The token is valid but the caller lacks the required permission.

    Attributes:
        required_permission: The permission that was needed.
    """

    def __init__(self, message: str, required_permission: str = "") -> None:
        super().__init__(message)
        self.required_permission = required_permission


class NoBindingError(AuthCheckError):
    """No permission binding is registered for this method + path combination."""


def _raise_for_reason(reason: str, required_permission: str) -> None:
    """Convert an auth-service denial reason string into the appropriate exception."""
    if reason == "token_expired":
        raise TokenExpiredError("Token has expired")
    if reason == "token_revoked":
        raise TokenRevokedError("Token has been revoked")
    if reason == "forbidden":
        raise PermissionDeniedError(
            f"Permission '{required_permission}' is required",
            required_permission=required_permission,
        )
    if reason == "no_binding":
        raise NoBindingError("No permission binding registered for this route")
    raise TokenInvalidError(f"Token is invalid: {reason}")
