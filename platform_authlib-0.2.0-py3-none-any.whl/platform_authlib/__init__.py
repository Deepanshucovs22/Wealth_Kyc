"""authlib — Auth client library for Covasant Platform SDK consumers.

Public surface::

    from platform_authlib import AuthClient, setup_auth, get_current_user
    from platform_authlib import require_permission, require_permission_check, no_auth

- :class:`AuthClient` — central client for token validation and binding resolution.
- :func:`setup_auth` — FastAPI lifespan helper that initialises the client and
  attaches it to ``app.state``.
- :func:`get_current_user` — FastAPI dependency that returns the authenticated user.
- :func:`require_permission` — decorator that tags a route with a required permission
  (used by the binding table / coverage checker at startup).
- :func:`require_permission_check` — factory producing a FastAPI Depends that enforces
  a permission at request time inside a handler (runtime check).
- :func:`no_auth` — decorator that exempts a FastAPI route from
  :class:`~authlib.middleware.AuthEnforcementMiddleware`.

Prometheus metrics (no-ops when prometheus_client is not installed):

- :func:`record_revocation_poll_failure` — increment revocation poll failure counter.
- :func:`record_revocation_set_size` — set revocation set size gauge.
- :func:`record_binding_refresh` — increment binding refresh counter.
- :func:`record_token_validation` — observe token validation duration.

Platform tenant isolation:

- :func:`build_tenant_allowlist` — build a frozenset of permitted tenant IDs.
- :func:`check_tenant_allowed` — check whether a JWT tenant is in the allowlist.
"""

from .client import AuthClient
from .dependencies import get_current_user, require_permission_check
from .lifespan import setup_auth
from .metrics import (
    record_binding_refresh,
    record_revocation_poll_failure,
    record_revocation_set_size,
    record_token_validation,
)
from .middleware import no_auth, require_permission
from .platform_isolation import build_tenant_allowlist, check_tenant_allowed

__all__ = [
    "AuthClient",
    "setup_auth",
    "get_current_user",
    # Route decorators
    "require_permission",
    "no_auth",
    # Runtime permission check dependency
    "require_permission_check",
    # Prometheus metrics
    "record_revocation_poll_failure",
    "record_revocation_set_size",
    "record_binding_refresh",
    "record_token_validation",
    # Platform tenant isolation
    "build_tenant_allowlist",
    "check_tenant_allowed",
]
