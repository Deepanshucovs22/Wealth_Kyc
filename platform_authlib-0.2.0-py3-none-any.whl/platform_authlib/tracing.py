"""OTel traceparent propagation for outbound httpx requests (D11-F8).

Provides an httpx transport that injects W3C traceparent headers on every
outbound request so that spans from authlib are connected to the caller's trace.
"""
import structlog

log = structlog.get_logger(__name__)

try:
    import httpx
    from opentelemetry import trace
    from opentelemetry.propagate import inject

    class TracingTransport(httpx.AsyncBaseTransport):
        """httpx transport that injects W3C traceparent into every request.

        Wrap the default transport: client = httpx.AsyncClient(transport=TracingTransport()).
        """

        def __init__(self, wrapped: httpx.AsyncBaseTransport | None = None) -> None:
            """Initialise with an optional wrapped transport; defaults to AsyncHTTPTransport."""
            self._wrapped = wrapped or httpx.AsyncHTTPTransport()

        async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
            """Inject traceparent header then delegate to the wrapped transport."""
            carrier: dict[str, str] = {}
            inject(carrier)
            for key, value in carrier.items():
                request.headers[key] = value
            return await self._wrapped.handle_async_request(request)

    def make_tracing_client(base_url: str, timeout: float = 10.0) -> "httpx.AsyncClient":
        """Create an httpx.AsyncClient that propagates OTel trace context."""
        return httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            transport=TracingTransport(),
        )

except ImportError:
    def make_tracing_client(base_url: str, timeout: float = 10.0):  # type: ignore[misc]
        """Fallback when opentelemetry-sdk is not installed. Returns plain httpx client."""
        import httpx
        log.debug("authlib.tracing.unavailable", reason="opentelemetry not installed")
        return httpx.AsyncClient(base_url=base_url, timeout=timeout)
