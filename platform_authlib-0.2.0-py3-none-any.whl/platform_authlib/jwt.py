"""JWT offline validation utilities.

Provides lightweight claim extraction and expiry checking without requiring
the auth service to be reachable.  Signature verification is intentionally
deferred to the auth service and is NOT performed here.
"""

from __future__ import annotations

import base64
import json
import time


class TokenExpiredError(Exception):
    """Raised when the JWT ``exp`` claim is in the past."""


class TokenRevokedError(Exception):
    """Raised when the JWT ``jti`` appears in the active revocation set."""


class TokenInvalidError(Exception):
    """Raised when the token is structurally malformed or unparsable."""


def validate_token_offline(token: str) -> dict:
    """Decode a JWT and verify its expiry without checking its signature.

    Splits the token on ``"."`` and base64url-decodes the payload segment.
    If the ``exp`` claim is present and is not in the future the token is
    considered expired.

    .. warning::
        This function does **not** verify the cryptographic signature.
        It is intended for fast, offline pre-checks only.  Full verification
        (including signature and revocation) is performed by
        :meth:`~authlib.client.AuthClient.validate_token`.

    Args:
        token: A compact-serialised JWT string (``header.payload.signature``).

    Returns:
        The decoded payload as a plain ``dict``.

    Raises:
        TokenInvalidError: If the token does not have three dot-separated
            segments or if the payload cannot be decoded as JSON.
        TokenExpiredError: If the ``exp`` claim is present and its value is
            less than or equal to the current Unix timestamp.
    """
    parts = token.split(".")
    if len(parts) != 3:
        raise TokenInvalidError(
            f"JWT must have exactly 3 segments, got {len(parts)}"
        )

    payload_segment = parts[1]
    # Restore base64url padding
    padding_needed = (4 - len(payload_segment) % 4) % 4
    payload_segment += "=" * padding_needed

    try:
        payload_bytes = base64.urlsafe_b64decode(payload_segment)
        claims: dict = json.loads(payload_bytes)
    except Exception as exc:
        raise TokenInvalidError(f"Failed to decode JWT payload: {exc}") from exc

    exp = claims.get("exp")
    if exp is not None:
        if int(exp) <= int(time.time()):
            raise TokenExpiredError(
                f"Token expired at {exp} (current time {int(time.time())})"
            )

    return claims
