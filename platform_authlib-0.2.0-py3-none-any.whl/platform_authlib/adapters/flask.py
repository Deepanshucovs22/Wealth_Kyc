"""Flask adapter for authlib (D8-F13).

Usage::

    from platform_authlib.adapters.flask import init_app, get_current_user, require_permission

    auth = AuthClient(auth_service_url="...", app_id="cams")

    # In your Flask app factory:
    init_app(app, auth)

    # In route handlers:
    @app.route("/api/v1/agents")
    @require_permission("agents:list")
    def list_agents():
        user = get_current_user()
        ...
"""
from __future__ import annotations

import asyncio
import functools
import structlog
from typing import TYPE_CHECKING, Callable, Any

if TYPE_CHECKING:
    from platform_authlib.client import AuthClient
    from platform_authlib.models import AuthenticatedUser

log = structlog.get_logger(__name__)

_AUTH_CLIENT: AuthClient | None = None
_CURRENT_USER_KEY = "authlib_user"


def init_app(app: Any, auth_client: "AuthClient") -> None:
    """Wire authlib into a Flask application.

    Registers a before_request handler that validates the JWT and sets
    flask.g.authlib_user for each authenticated request.

    Args:
        app: The Flask application instance.
        auth_client: An initialised AuthClient.
    """
    global _AUTH_CLIENT
    _AUTH_CLIENT = auth_client

    try:
        from flask import g, request, jsonify

        @app.before_request
        def _enforce_auth():
            if _AUTH_CLIENT is None:
                return
            # Extract token
            token = None
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
            if not token:
                return jsonify({"error": "missing token"}), 401
            try:
                loop = asyncio.new_event_loop()
                user = loop.run_until_complete(
                    _AUTH_CLIENT.check(token, request.method, request.path)
                )
                loop.close()
                g.authlib_user = user
            except Exception as exc:
                log.warning("flask.auth.failed", error=str(exc))
                return jsonify({"error": str(exc)}), 401

    except ImportError:
        log.warning("authlib.flask_adapter.unavailable", reason="flask not installed")


def get_current_user() -> "AuthenticatedUser":
    """Return the authenticated user from the Flask request context.

    Must be called inside a Flask request context after init_app has been called.

    Raises:
        RuntimeError: If Flask is not installed or init_app was not called.
    """
    try:
        from flask import g
        user = getattr(g, _CURRENT_USER_KEY, None)
        if user is None:
            raise RuntimeError("no authenticated user in request context")
        return user
    except ImportError as exc:
        raise RuntimeError("flask is not installed") from exc


def require_permission(permission: str) -> Callable:
    """Route decorator that checks a specific permission after authentication.

    Args:
        permission: The permission name to check (e.g., "agents:list").

    Returns:
        A decorator that enforces the permission check.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                from flask import jsonify
            except ImportError:
                return func(*args, **kwargs)
            user = get_current_user()
            if not user.has_permission(permission):
                log.warning(
                    "flask.permission.denied",
                    permission=permission,
                    user_id=user.user_id,
                )
                return jsonify({"error": f"missing permission: {permission}"}), 403
            return func(*args, **kwargs)
        return wrapper
    return decorator
