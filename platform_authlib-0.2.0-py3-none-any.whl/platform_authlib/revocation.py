"""Background poller that maintains an up-to-date set of revoked JTIs.

The poller fetches revocation records from the auth service on a configurable
interval and keeps an in-memory frozenset of active JTI strings.  Token
validation code calls :meth:`RevocationPoller.is_revoked` synchronously so
the hot path has no I/O overhead.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import structlog

from . import metrics

if TYPE_CHECKING:
    import httpx

log = structlog.get_logger(__name__)

_REVOCATIONS_PATH = "/api/v1/revocations"


class RevocationPoller:
    """Async background task that polls the auth service for revoked tokens.

    The poller stores a snapshot of revoked JTIs as a :class:`frozenset` so
    that :meth:`is_revoked` can answer without acquiring any lock.  On every
    poll the set is replaced atomically with the full active revocation list
    from the auth service; the auth service already excludes expired records.

    Args:
        http: Shared :class:`httpx.AsyncClient` pointed at the auth service base URL.
        app_id: Application identifier used to scope the revocation query.
        tenant_id: Tenant identifier; included in the poll request.
        poll_interval: Seconds between consecutive poll requests.  Defaults to ``30``.
    """

    def __init__(
        self,
        http: "httpx.AsyncClient",
        app_id: str,
        tenant_id: int,
        poll_interval: float = 30.0,
    ) -> None:
        """Initialise with an empty revocation set."""
        self._http = http
        self._app_id = app_id
        self._tenant_id = tenant_id
        self._poll_interval = poll_interval
        self._revoked: frozenset[str] = frozenset()
        self._task: asyncio.Task | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Schedule the background poll loop as an asyncio task.

        Must be called from within a running event loop (e.g. inside an
        ``async`` function or a lifespan handler).
        """
        self._task = asyncio.create_task(
            self._poll_loop(), name=f"authlib-revocation-poller-{self._app_id}"
        )
        log.info(
            "authlib.revocation.poller_started",
            app_id=self._app_id,
            poll_interval=self._poll_interval,
        )

    async def close(self) -> None:
        """Cancel the poll task and wait for it to finish.

        Safe to call even if :meth:`start` was never called.
        """
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        log.info("authlib.revocation.poller_stopped", app_id=self._app_id)

    # ------------------------------------------------------------------
    # Public query
    # ------------------------------------------------------------------

    def is_revoked(self, jti: str) -> bool:
        """Return ``True`` if *jti* is in the current revocation set.

        This is a synchronous, lock-free read against a :class:`frozenset`
        and is safe to call from any coroutine or thread.

        Args:
            jti: JWT ID string from the token's ``jti`` claim.

        Returns:
            ``True`` if the token has been explicitly revoked.
        """
        return jti in self._revoked

    # ------------------------------------------------------------------
    # Internal poll loop
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        """Continuously sleep then fetch fresh revocation data.

        On each iteration:
        1. Sleep for ``poll_interval`` seconds.
        2. GET the full active revocation list from the auth service.
        3. Replace ``self._revoked`` atomically with the new set.

        :class:`asyncio.CancelledError` is re-raised immediately to allow the
        task to be cancelled cleanly.  All other exceptions are logged at
        WARNING level and the loop continues.
        """
        while True:
            try:
                await asyncio.sleep(self._poll_interval)
                await self._fetch_and_update()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                metrics.record_revocation_poll_failure(self._app_id)
                log.warning(
                    "authlib.revocation.poll_error",
                    app_id=self._app_id,
                    error=str(exc),
                )

    async def _fetch_and_update(self) -> None:
        """Fetch the full active revocation list and replace the in-memory set atomically.

        Requests all currently active (non-expired) revocations from the auth
        service without an ``after`` filter.  The auth service DB query already
        filters out expired records (``expires_at > NOW()``), so the response is
        always the exact current truth.  Replacing the set atomically on every
        poll means there is no accumulation state to go wrong.
        """
        if self._tenant_id <= 0:
            log.debug(
                "authlib.revocation.poll_skip",
                app_id=self._app_id,
                reason="tenant_id not yet resolved",
            )
            return

        response = await self._http.get(
            _REVOCATIONS_PATH,
            params={
                "app_id": self._app_id,
                "tenant_id": self._tenant_id,
            },
        )
        response.raise_for_status()

        records: list[dict] = response.json()

        new_revoked: set[str] = set()
        for record in records:
            try:
                jti = record["jti"]
                if jti:
                    new_revoked.add(jti)
            except KeyError:
                log.warning(
                    "authlib.revocation.malformed_record",
                    record=record,
                )

        self._revoked = frozenset(new_revoked)

        metrics.record_revocation_set_size(self._app_id, self._tenant_id, len(self._revoked))

        log.info(
            "authlib.revocation.updated",
            app_id=self._app_id,
            revoked_count=len(self._revoked),
        )
