"""Prometheus metrics for authlib (D11-F6).

Optional: metrics are only registered when prometheus_client is installed.
If not installed, all RecordX functions are no-ops so authlib does not
require prometheus_client as a hard dependency.
"""
import structlog

log = structlog.get_logger(__name__)

_METRICS_AVAILABLE = False
try:
    from prometheus_client import Counter, Histogram, Gauge
    _METRICS_AVAILABLE = True
except ImportError:
    pass

if _METRICS_AVAILABLE:
    _revocation_poll_failures = Counter(
        "authlib_revocation_poll_failures_total",
        "Total number of failed revocation poll attempts",
        ["app_id"]
    )
    _revocation_set_size = Gauge(
        "authlib_revocation_set_size",
        "Current number of entries in the in-process revocation set",
        ["app_id", "tenant_id"]
    )
    _binding_refresh_total = Counter(
        "authlib_binding_refresh_total",
        "Total binding table refresh operations",
        ["app_id", "source"]  # source: memcached | api
    )
    _token_validation_duration = Histogram(
        "authlib_token_validation_duration_seconds",
        "JWT token validation duration",
        ["app_id"],
        buckets=[0.001, 0.005, 0.01, 0.025, 0.05, 0.1]
    )


def record_revocation_poll_failure(app_id: str) -> None:
    """Increment the revocation poll failure counter."""
    if _METRICS_AVAILABLE:
        _revocation_poll_failures.labels(app_id=app_id).inc()


def record_revocation_set_size(app_id: str, tenant_id: int, size: int) -> None:
    """Set the current revocation set size gauge."""
    if _METRICS_AVAILABLE:
        _revocation_set_size.labels(app_id=app_id, tenant_id=str(tenant_id)).set(size)


def record_binding_refresh(app_id: str, source: str) -> None:
    """Increment binding refresh counter with source label."""
    if _METRICS_AVAILABLE:
        _binding_refresh_total.labels(app_id=app_id, source=source).inc()


def record_token_validation(app_id: str, duration_seconds: float) -> None:
    """Observe token validation duration."""
    if _METRICS_AVAILABLE:
        _token_validation_duration.labels(app_id=app_id).observe(duration_seconds)
