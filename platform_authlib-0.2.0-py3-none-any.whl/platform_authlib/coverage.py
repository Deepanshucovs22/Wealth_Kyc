"""Startup coverage check: compares registered FastAPI routes against the binding table.

D12-F7: On startup, authlib compares every registered FastAPI route against the binding table.
Routes that have no binding entry and are not in the public_paths list are flagged.
"""

import structlog
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from platform_authlib.binding import BindingTable

log = structlog.get_logger(__name__)

def check_coverage(app, binding_table: "BindingTable", mode: str = "warn") -> list[dict]:
    """Check that all FastAPI routes have a corresponding binding table entry or are public.

    Args:
        app: The FastAPI application instance.
        binding_table: The loaded BindingTable from the auth service.
        mode: "warn" emits log warnings for uncovered routes.
              "error" raises RuntimeError if any uncovered routes are found.
              "off" disables the check entirely.

    Returns:
        List of dicts describing uncovered routes: [{"method": str, "path": str}]

    Raises:
        RuntimeError: If mode is "error" and uncovered routes are found.
    """
    if mode == "off":
        return []

    try:
        from fastapi.routing import APIRoute
        routes = [r for r in app.routes if isinstance(r, APIRoute)]
    except ImportError:
        log.warning("coverage_check.skipped", reason="fastapi not installed")
        return []

    uncovered = []
    for route in routes:
        # Routes explicitly exempted from auth enforcement via @no_auth
        if getattr(route.endpoint, "_no_auth", False):
            continue
        for method in route.methods or []:
            path = route.path
            if binding_table.is_public(method, path):
                continue
            # Routes with an explicit @require_permission are intentionally covered
            if getattr(route.endpoint, "_required_permission", None):
                continue
            permission = binding_table.resolve(method, path)
            if permission is None:
                uncovered.append({"method": method, "path": path})

    if uncovered:
        for entry in uncovered:
            log.warning("coverage_check.uncovered_route",
                       method=entry["method"], path=entry["path"])
        if mode == "error":
            paths = ", ".join(f"{e['method']} {e['path']}" for e in uncovered)
            raise RuntimeError(f"auth coverage check failed: uncovered routes: {paths}")
    else:
        log.info("coverage_check.passed", route_count=len(routes))

    return uncovered
